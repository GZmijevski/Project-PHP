# PUCPR_2024
Projeto da Equipe7 da disciplina de experiencia criativa.

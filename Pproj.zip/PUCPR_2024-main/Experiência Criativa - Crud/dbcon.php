<?php

$con = mysqli_connect("localhost","root","","JBB");

if(!$con){
    die('Connection Failed'. mysqli_connect_error());
}

?>